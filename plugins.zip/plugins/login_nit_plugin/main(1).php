<?php
/*
Plugin Name: registration plugin
Description: A test plugin to demonstrate wordpress functionality
Author: Nitish Gaur
Version: 0.1
*/
  ?> 
<?php 
error_reporting(0);
add_action('admin_menu', 'my_menu_pages');
function my_menu_pages(){
    add_menu_page('My Page Title', 'custom registration', 'manage_options','my-unique-identifier', 'registration' );
     
    add_menu_page('my login title','user login', 'manage_options','user login', 'login' );

}

function registration($atts){



global $wpdb;
    
    $welcome_name = $_POST['namesignup'];
    $welcome_loginname = $_POST['loginsignup'];
    $welcome_email = $_POST['usernamesignup'];
    $welcome_password = md5($_POST['passwordsignup']);
    $welcome_passwordcnfrm = md5($_POST['passwordsignup_confirm']);
    
    $table_name = $wpdb->prefix . 'users';
    $atts = shortcode_atts(array('role' => ''), $atts);
    if (isset($_POST['submit']))
         {
             
             $sign= $wpdb->get_results("SELECT * From wp_users WHERE user_email='".$welcome_email."' or user_login= '".$welcome_loginname."'" );
            

            if ($wpdb->num_rows > 0) {
                echo "user already exists";
            }
            
         elseif($welcome_password == $welcome_passwordcnfrm) 
             {

                $wpdb->insert( 
                                $table_name, 
                                array( 
                                        'id' => NULL,
                                        'user_registered' => current_time( 'mysql' ), 
                                        'user_login' => $welcome_loginname, 
                                        'user_email' => $welcome_email, 
                                        'user_pass' => $welcome_password,
                                        'user_nicename' => $welcome_name,
                                        'display_name' => $welcome_name,
                                        //'wp_capabilities' => $atts['role']
                                      ) 
                                    );
                $rid = $wpdb->get_var("SELECT id FROM wp_users WHERE user_email = '".$welcome_email."' and user_pass= '".$welcome_password."'");
                echo "user created";

                $user = new WP_User( $rid );           
                $user->set_role( $atts['role'] );
                $thnx = thanks();
                echo $thnx;
                /*//$location = plugins_url('registration_plugin/signupthanku.php');
                //header('http://192.168.0.16/nitish/wordpress/wordpress/wp-content/plugins/registration_plugin/signupthanku.php');
                
                ob_start();
                //header('Location: '.$location);
                
                
                $id = 479;
                $post_id = get_permalink($id);

                 //echo $post_id; 
                echo wp_redirect($post_id);
                exit();*/
                
                
                        }
            else            
            {
                echo " password is not same";

            } 
}




   echo '

            <div id="register" class="wrap">
            <form  action=""  method="post"> 
                <h1 text-align="centre"> Sign up </h1><br> 
                <p> 
                    <label for="usernamesignup" class="uname" data-icon="n">Your name</label>
                    <input id="usernamesignup" name="namesignup" required="required" type="text" placeholder="rahul" />
                </p><br>
                 <p> 
                    <label for="userloginsignup" class="loginname" data-icon="u">Your username</label>
                    <input id="userloginsignup" name="loginsignup" required="required" type="text" placeholder="mysuperusername690" />
                </p><br>
                <p> 
                    <label for="emailsignup" class="youmail" data-icon="e" > Your email</label>
                    <input id="emailsignup" name="usernamesignup" required="required" type="email" placeholder="mysupermail@mail.com"/> 
                </p><br>
                <p> 
                    <label for="passwordsignup" class="youpasswd" data-icon="p">Your password </label>
                    <input id="passwordsignup" name="passwordsignup" required="required" type="password" placeholder="eg. X8df!90EO"/>
                </p><br>
                <p> 
                    <label for="passwordsignup_confirm" class="youpasswd" data-icon="p">Please confirm your password </label>
                    <input id="passwordsignup_confirm" name="passwordsignup_confirm" required="required" type="password" placeholder="eg. X8df!90EO"/>
                </p><br>
               
        <p class="signin button"> 
                    <input type="submit" name="submit" value="Sign up"/> 
                </p><br><br>
                
            </form>
       
        
    
</div><br>';

           
   } 

   function thanks()
   {
    echo "thanks for sign_up";

   }
   add_action('', 'thanks');

function login(){
    global $wpdb;
    echo '
   <div class="form">
<form name="login" action="" method="post" >
 <h1>login</h1>
  <ul>
    <li><label for="usermail">Enter email or username</label>
    <input type="text" name="usermail" placeholder="yourname@email.com or mysuperusername690" required></li><br>
    <li><label for="password">Password</label>
    <input type="password" name="password" placeholder="password" required></li><br>
    <li>
    <input type="submit" name="login_btn" value="Login"></li>
  </ul>
</form><br></div>';



if (isset($_POST['login_btn'])) {
  $password_login = md5($_POST['password']);  
  $usermail = $_POST['usermail'];

 $login = $wpdb->get_results("SELECT * FROM wp_users WHERE user_email = '".$usermail."' or user_login = '".$usermail."' and user_pass= '".$password_login."'  ");

    
   if($wpdb->num_rows > 0) // if uname/pass correct it returns must be 1 row
   {
   
     $rol = $wpdb->get_var("SELECT user_role FROM wp_user WHERE user_email = '".$usermail."' or user_login = '".$usermail."' and user_pass= '".$password_login."' ");
     $uid = $wpdb->get_var("SELECT id FROM wp_users WHERE user_email = '".$usermail."' or user_login = '".$usermail."' and user_pass= '".$password_login."'");
     $uid2=get_metadata('user',$uid,'wp_capabilities');
      
      
     /*if ($rol == 'administrator' || $rol == 'super admin' || $rol == 'editor' || $rol == 'author' || $rol == 'contributor' || $rol == 'subscriber') {
         echo $rol;
         //get_role($rol);
     }*/
   //if(wp_check_password($password_login,wp_hash_password($login['passwordsignup'])))
   //{

    $g = get_site_url();
    echo $g;
     wp_redirect($g);

    
   }
    else 
    {
    
    echo "invalid user";
    }
    
}}
add_action('muplugins_loaded', 'login');
add_action( 'muplugins_loaded', 'registration' );
add_shortcode('login-1', 'login');
  
 add_shortcode('signup', 'registration');
 
 /*global $jal_db_version;
$jal_db_version = '1.0';

function jal_install() {
    global $wpdb;
    global $jal_db_version;

    $table_name = $wpdb->prefix . 'custom_registration';
    
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        namesignup text NOT NULL,
        usernamesignup varchar(55) NOT NULL,
        passwordsignup varchar(55) DEFAULT '' NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );

    add_option( 'jal_db_version', $jal_db_version );
}
register_activation_hook( __FILE__, 'jal_install' );

*/
?>




