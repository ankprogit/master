#######################################################

 Magic Zoom Plus™
 WooCommerce module version v6.7.0 [v1.6.64:v5.2.4]
 
 www.magictoolbox.com
 support@magictoolbox.com

 Copyright 2017 Magic Toolbox

#######################################################

INSTALLATION:

1. Upload the zip file via your WordPress admin area.

2. Activate Magic Zoom Plus plugin for WooCommerce in the Plugins menu of WordPress.

3. Magic Zoom Plus is ready to use!

4. To upgrade your version of Magic Zoom Plus (which removes the "Please upgrade" text), buy Magic Zoom Plus and overwrite the wp-content/plugins/magiczoomplus-woocommerce/magiczoomplus-woocommerce/core/magiczoomplus.js file file with the new one in your licensed version.

Buy a single license here:

http://www.magictoolbox.com/buy/magiczoomplus/

