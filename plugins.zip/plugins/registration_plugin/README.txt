=== Plugin Name ===
Contributors: e-coding hub pvt. ltd.
Requires at least: 4.6
Tested up to: 4.8
Stable tag: 4.3


Here is a short description of the plugin. No markup here.

== Description ==

The purpose of This plugin is user registeration and login into wordpress. The advanced functionality of this plugin is that a user can assign the role through the shortcode. A user register and login without refreshing the page which means that ajax is used for registering and login.  

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/plugin-name` directory.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use shortcode  in your theme custom template "do_shortcode('[signup role="editor"]')".
4. enjoy


