<?php
/*
Plugin Name: users plugin
Description: A test plugin to demonstrate wordpress functionality
Author: Nitish Gaur
Version: 0.1
*/
  ?> 
<?php 
add_action('init', 'init_theme_method');
 
function init_theme_method() {
   add_thickbox();
}


add_action('admin_menu', 'my_menu_pages');
function my_menu_pages(){
    //add_menu_page('My Page Title', 'custom users', 'manage_options','my-unique-identifier', 'users' );
     
    add_menu_page('my login title','user login', 'manage_options','user_login', 'login' );
    add_submenu_page('user_login','settings','settings','manage_options','settings','settings');

}
/*function wpdocs_scripts_method() {
   wp_enqueue_script( 'newscript', plugins_url( '/js/newscript.js' , __FILE__ ), array( 'jquery' ) );
wp_localize_script( 'inkthemes', 'MyAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php')));
}
add_action( 'wp_enqueue_scripts', 'wpdocs_scripts_method' ); */
function settings()
{ 
  global $wpdb;
$table_name = $wpdb->prefix.'save_changes';
$heading_qry = $wpdb->get_var("SELECT heading FROM $table_name WHERE heading IS NOT NULL order by id desc limit 1");
$button_text_qry = $wpdb->get_var("SELECT button FROM $table_name WHERE button IS NOT NULL order by id desc limit 1");
$field_table = $wpdb->prefix.'fields';

?>

<script>
  jQuery(document).ready(function(){
    jQuery("#add_fields").click(function(){
      jQuery("#add_form_fields").css("display", "block");
    });
});
</script>
<style type="text/css">
  #add_form_fields{ display: none; }
</style>
<form action="" method="post" name="settings_form">
enter heading of signup form :<input type="text" name="heading_text" id ="heading_text" placeholder="<?php echo $heading_qry ?>"> <br>
enter text of button : <input type="text" name="button_text" id="button_text" placeholder="<?php echo $button_text_qry ?>"><br>
<input type="submit" name="save_changes" value="save_changes"><br><br><br><br>
<input type="button" name="add_fields" value="add_fields" id="add_fields">
</form> <br>
<!-- checkbox code -->
<form method="post" action="" name="add_form_fields" id="add_form_fields">
<label class="heading">Select fields:</label><br>
<input type="checkbox" name="check_list[]" value="1"><label>first name</label><br>
<input type="checkbox" name="check_list[]" value="2"><label>last name</label><br>
<input type="checkbox" name="check_list[]" value="3"><label>D.O.B</label><br>
<input type="checkbox" name="check_list[]" value="4"><label>phone_number</label><br><br>

<input type="submit" name="add_fields" Value="add_fields" >
</form>
<?php
if (isset($_POST['add_fields'])) {
  $checkBox = implode(',', $_POST['check_list']);
   $wpdb->insert( 
                                $field_table, 
                                array( 
                                        'id' => NULL,
                                        'post_time' => current_time( 'mysql' ), 
                                        'fields' => $checkBox, 
                                        
                                        //'wp_capabilities' => $atts['role']
                                      ) 
                                    );
   echo "fields added successfully";

}
        

if (isset($_POST['save_changes'])) {
  $heading = $_POST['heading_text'];
  $button = $_POST['button_text'];
  if ($button == '' && $heading == '') {
    echo "Please fill above fields";
  }
  elseif ($button == '' && $heading != '' ) {
    $wpdb->insert( 
                                $table_name, 
                                array( 
                                        'id' => NULL,
                                        'post_time' => current_time( 'mysql' ), 
                                        'heading' => $heading, 
                                        
                                        //'wp_capabilities' => $atts['role']
                                      ) 
                                    );
    echo "heading updated successfully";
  }
  elseif ($button != '' && $heading == '' ) {
    $wpdb->insert( 
                                $table_name, 
                                array( 
                                        'id' => NULL,
                                        'post_time' => current_time( 'mysql' ), 
                                        'button' => $button, 
                                        
                                        //'wp_capabilities' => $atts['role']
                                      ) 
                                    );
    echo "button text updated successfully";
  }
  else
  {
     $wpdb->insert( 
                                $table_name, 
                                array( 
                                        'id' => NULL,
                                        'post_time' => current_time( 'mysql' ), 
                                        'heading' => $heading,
                                        'button' => $button, 
                                        
                                        //'wp_capabilities' => $atts['role']
                                      ) 
                                    );
    echo "heading and button_text updated successfully";
  }
}

}
add_action('', 'login');

function addCustomer_fun(){
  //print_r($_POST); 
  
global $wpdb;
$table_user = $wpdb->prefix."extra_fields";
$table_name = $wpdb->prefix."users";
// Fetching Values From URL
$name2 = $_POST['name1'];
$email2 = $_POST['email1'];
$password2 = md5($_POST['password1']);
$website1 = $_POST['website1'];
$atts = $_POST['role1'];
$fn = $_POST['firstname1'];
$ln = $_POST['lastname1'];
$d = $_POST['dob1'];
$ph = $_POST['phone1'];


 
$login = $wpdb->get_results("SELECT * FROM $table_name WHERE user_email = '".$email2."' ");
      if($wpdb->num_rows > 0) // if uname/pass correct it returns must be 1 row
   {
       $v = 1;
       echo $v;
   }
    else 
    {
    
    
    


$wpdb->insert( 
                                $table_name, 
                                array( 
                                        'id' => NULL,
                                        'user_registered' => current_time( 'mysql' ), 
                                        'user_login' => $name2, 
                                        'user_email' => $email2, 
                                        'user_pass' => $password2, 
                                        'display_name' => $name2,
                                        'user_url' => $website1,
                                        //'wp_capabilities' => $atts['role']
                                      ) 
                                    );
                      echo 2;
$rid = $wpdb->get_var("SELECT id FROM $table_name WHERE user_email = '".$email2."' or user_login = '".$name2."' and user_pass= '".$password2."'");
              
               $user = new WP_User( $rid );           
                $user->set_role( $atts );
				add_user_meta( $rid, 'nickname', $name2);
				add_user_meta( $rid, 'first_name', $fn );
				add_user_meta( $rid, 'last_name', $ln );
				add_user_meta( $rid, 'wpcfbirth_date', $d );
				
				add_user_meta( $rid, 'phone', $ph);
				
  }}
add_action('wp_ajax_addCustomer', 'addCustomer_fun');
add_action('wp_ajax_nopriv_addCustomer', 'addCustomer');
function users(){



/*global $wpdb;
    
    $welcome_name = $_POST['namesignup'];
    $welcome_loginname = $_POST['loginsignup'];
    $welcome_email = $_POST['usernamesignup'];
    $welcome_password = md5($_POST['passwordsignup']);
    $welcome_passwordcnfrm = md5($_POST['passwordsignup_confirm']);
    
    $table_name = $wpdb->prefix . 'users';
    $atts = shortcode_atts(array('role' => ''), $atts);
    if (isset($_POST['submit']))
         {
             
             $sign= $wpdb->get_results("SELECT * From wp_users WHERE user_email='".$welcome_email."' or user_login= '".$welcome_loginname."'" );
            

            if ($wpdb->num_rows > 0) {
                echo "user already exists";
            }
            
         elseif($welcome_password == $welcome_passwordcnfrm) 
             {

                $wpdb->insert( 
                                $table_name, 
                                array( 
                                        'id' => NULL,
                                        'user_registered' => current_time( 'mysql' ), 
                                        'user_login' => $welcome_loginname, 
                                        'user_email' => $welcome_email, 
                                        'user_pass' => $welcome_password, 
                                        'user_nicename' => $welcome_name,
                                        'display_name' => $welcome_name,
                                        //'wp_capabilities' => $atts['role']
                                      ) 
                                    );
                $rid = $wpdb->get_var("SELECT id FROM wp_users WHERE user_email = '".$welcome_email."' and user_pass= '".$welcome_password."'");
                echo "user created";

                $user = new WP_User( $rid );           
                $user->set_role( $atts['role'] );
                $thnx = thanks();
                echo $thnx;
                /*$location = plugins_url('users_plugin/signupthanku.php');
                //header('http://192.168.0.16/nitish/wordpress/wordpress/wp-content/plugins/users_plugin/signupthanku.php');
                
                ob_start();
                //header('Location: '.$location);
                
                
                $id = 479;
                $post_id = get_permalink($id);

                 //echo $post_id; 
                echo wp_redirect($post_id);
                exit();
                
                
                        }
            else            
            {
                echo " password is not same";

            } 
}
*/
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
  $("#button").click(function(){

  
    var name = $('#usernamesignup').val();
    var email = $('#emailsignup').val();
    var login = $('#userloginsignup').val();
    var password = $('#passwordsignup').val();
    var cpassword = $('#passwordsignup_confirm').val();
    
    var dataString = {action: "addCustomer",  'name1': name , 'email1' : email , 'password1' : password , 'login1' : login};
     var ajaxurl="<?php echo admin_url( 'admin-ajax.php' ); ?>";
       if (name == '' || email == '' || password == '' || login == '' || cpassword == '') {
          alert("Please Fill All Fields");
        } else {
          
          jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: dataString,

            
            success: function(html) {
            alert(html);
            }
        
        });
      }
});
});

</script>

 


   

            <div id="register" class="wrap">
            <form  action=""  method="post"> 
                <h1 text-align="centre"> Sign up </h1><br> 
                <p> 
                    <label for="usernamesignup" class="uname" data-icon="n">Your name</label>
                    <input id="usernamesignup" name="namesignup" required="required" type="text" placeholder="rahul" />
                </p><br>
                 <p> 
                    <label for="userloginsignup" class="loginname" data-icon="u">Your username</label>
                    <input id="userloginsignup" name="loginsignup" required="required" type="text" placeholder="mysuperusername690" />
                </p><br>
                <p> 
                    <label for="emailsignup" class="youmail" data-icon="e" > Your email</label>
                    <input id="emailsignup" name="usernamesignup" required="required" type="email" placeholder="mysupermail@mail.com"/> 
                </p><br>
                <p> 
                    <label for="passwordsignup" class="youpasswd" data-icon="p">Your password </label>
                    <input id="passwordsignup" name="passwordsignup" required="required" type="password" placeholder="eg. X8df!90EO"/>
                </p><br>
                <p> 
                    <label for="passwordsignup_confirm" class="youpasswd" data-icon="p">Please confirm your password </label>
                    <input id="passwordsignup_confirm" name="passwordsignup_confirm" required="required" type="password" placeholder="eg. X8df!90EO"/>
                </p><br>
               
        <p class="signin button"> 
                    <input type="button" name="submit" id="button" value="Sign up"  /> 
                </p><br><br>
                
            </form>
       
        
    
</div><br>
<!--<div id="myDiv" style="color:#993300;text-align:center;width:200px;border:1px solid #F8F8F8"></div>
<?php
echo "short code: [signup role=' '] <br> e.g:[signup role='author']";
           
   } 

  
   function userlogin()
   {
    global $wpdb;
    $table_name = $wpdb->prefix."users";
// Fetching Values From URL
      $name2 = $_POST['name12'];
     
      $password2 = md5($_POST['password12']);
      $login = $wpdb->get_results("SELECT * FROM $table_name WHERE user_email = '".$name2."' or user_login = '".$name2."' and user_pass = '".$password2."'  ");
      if($wpdb->num_rows > 0) // if uname/pass correct it returns must be 1 row
   {
      echo "login successfully";
    }
    else 
    {


     echo "invalid user";
    }



   }
add_action('wp_ajax_user', 'userlogin');
add_action('wp_ajax_nopriv_user', 'user');

/*function valid()
{ 
  $name = $_POST['name1'];
$pass = $_POST['password1'];
$email = $_POST['email1'];
$web = $_POST['website1'];
echo $name;
echo $pass;
// Check Valid or Invalid user name when user enters user name in username input field.

if (strlen($name) < 4) {
echo "Must be 3+ letters";
} else {
echo "<span>Valid</span>";
}

// Check Valid or Invalid password when user enters password in password input field.

if (strlen($pass) < 6) {
echo "Password too short";
} else {
echo "<span>Strong</span>";
}

// Check Valid or Invalid email when user enters email in email input field.

if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/", $email)) {
echo "Invalid email";
} else {
echo "<span>Valid</span>";
}

// Check Valid or Invalid website address when user enters website address in website input field.

if (!preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i", $web)) {
echo "Invalid website";
} else {
echo "<span>Valid</span>";
}

}
add_action('wp_ajax_valida', 'valid');
add_action('wp_ajax_nopriv_valida', 'valida');

*/

function login($atts){
    global $wpdb;
    ?>
<style type="text/css">
  #firstname1,#firstname,#lastname1,#lastname,#dob1,#dob,#phone1,#phone{display: none;}
</style>
    <?php
    $welcome_role = $_POST['role'];
        $atts = shortcode_atts(
        array(
            'role' => '',
            )
            , $atts);
        $welcome_email = $_POST['uemail'];
        $welcome_password = md5($_POST['upassword']);
        $welcome_name = $_POST['username'];
        print_r($atts);
        $settings_table = $wpdb->prefix.'save_changes';

$heading_qry = $wpdb->get_var("SELECT heading FROM $settings_table WHERE heading IS NOT NULL order by id desc limit 1");
$button_text_qry = $wpdb->get_var("SELECT button FROM $settings_table WHERE button IS NOT NULL order by id desc limit 1");
$fields_table = $wpdb->prefix.'fields';
$field_qry = $wpdb->get_col("SELECT fields FROM $fields_table WHERE fields order by id desc limit 1");
$arr = implode(',', $field_qry);
$arr2 = explode(',', $arr);
print_r($arr2);


  if (in_array(1, $arr2)) 
    
      echo '<style>#firstname1{display: block;}</style>';
    
    
        
  if (in_array(2, $arr2))   
      echo '<style>#lastname1{display: block;}</style>';
    
    
  
  if (in_array(3, $arr2)) 
    
      echo '<style>#dob1{display: block;}</style>';
    
    
  
  if (in_array(4, $arr2))   
      echo '<style>#phone1{display: block;}</style>';
    
    
  
     
?>

<style type="text/css">
  #luser,#lpassword,#lsu{
    display: none;
  }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
  $("#button1").click(function(){

  
    var name12 = $('#lname').val();
    var password12 = $('#lpass').val();
    
    var ldata = {action: "user",  'name12': name12 , 'password12' : password12 };
     var ajaxurl="<?php echo admin_url( 'admin-ajax.php' ); ?>";
       if (name12 == '' && password12 == '' ) {
          $("#luser").css({display : "block",color : "red"});
                           $("#lpassword").css({display : "block",color : "red"});
        }
        else if( name12 == '' && password12 != '')
        {
           $("#luser").css({display : "block",color : "red"});
            $("#lpassword").css({display : "none"});
        }
        else if(name12 != '' && password12 == '')
        {
           $("#luser").css({display : "none"});
           $("#lpassword").css({display : "block",color : "red"});
        }
         else {
          
          jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: ldata,

            
            success: function(html) {
            alert(html);
            }
        
        });
      }
});
});

 $(document).ready(function(){
  $("#r_button").click(function(){
    
  
   
var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      alert("hello");
    }
  }
// Fetching values from all input fields and storing them in variables.


    var name1 = $('#username1').val();
    var password1 = $('#password1').val();
    var email1 = $('#email1').val();
    var website1 = $('#website1').val();
    var role = $('#role1').val();
    var firstname1 = $('#first').val();
    var lastname1 = $('#last').val();
    var dob1 = $('#date').val();
    var phone1 = $('#numb').val();
    var udata = {action: "addCustomer",  'name1': name1 , 'password1' : password1 , 'email1' : email1 , 'website1' : website1 , 'role1' : role, 'firstname1' : firstname1, 'lastname1': lastname1, 'dob1': dob1, 'phone1' : phone1  };
    var ajaxurl="<?php echo admin_url( 'admin-ajax.php' ); ?>";
    var atpos = email1.indexOf("@");
    var dotpos = email1.lastIndexOf(".");

       if (name1 == '' && password1 == '' && email1 == '' && website1 == '' ) {
		   if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }

                            $("#username").css({display : "block",color : "red"});
                           $("#password").css({display : "block",color : "red"});
                            $("#email").css({display : "block",color : "red"});
                            $("#website").css({display : "block",color : "red"});

                                               
        }

        else if (name1 == '' && email1 == '' && website1 == '' && password1 != '' )
		{
						if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
                                         $("#password").css({display : "none"});

                 
                            $("#username").css({display : "block",color : "red"});
                                      $("#email").css({display : "block",color : "red"});
                                                $("#website").css({display : "block",color : "red"});



          

        } else if(password1 == '' && email1 == '' && website1 == '' && name1 != '')
        {
			if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
                                      $("#username").css({display : "none"});

           $("#password").css({display : "block",color : "red"});
          $("#email").css({display : "block",color : "red"});
          $("#website").css({display : "block",color : "red"});
        }
        else if(name1 == '' && website1 == '' && password1 == '' && email1 != '')
        {
            if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email1.length)
            {
				if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
              $("#username").css({display : "block",color : "red"});
                      $("#website").css({display : "block",color : "red"});
                      $("#password").css({display : "block",color : "red"});
                      $("#email").css({display : "block",color : "red"});

            }
            else{
				if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
                        $("#email").css({display : "none"});

                      $("#username").css({display : "block",color : "red"});
                      $("#website").css({display : "block",color : "red"});
                      $("#password").css({display : "block",color : "red"});

                   } }
        else if(name1 == '' && password1 == '' && email1 == '' && website1 != '')
        {
			if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
                                                $("#website").css({display : "none"});

          $("#username").css({display : "block",color : "red"});
          $("#password").css({display : "block",color : "red"});
          $("#email").css({display : "block",color : "red"});
        }
        else if(name1 == '' && password1 == '' && website1 != '' && email1 != '')
        {
          if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email1.length)
             {
				 if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
              $("#username").css({display : "block",color : "red"});
          $("#password").css({display : "block",color : "red"});
          $("#email").css({display : "block",color : "red"});
          $("#website").css({display : "none"});
             }
             else{
				 if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
                                                          $("#website").css({display : "none"});
                                                          $("#email").css({display : "none"});

          $("#username").css({display : "block",color : "red"});
          $("#password").css({display : "block",color : "red"});
        }}
        else if(name1 == '' && email1 == '' && website1 != '' && password1 != '' )
        {
			if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
                    $("#username").css({display : "block",color : "red"});
                                                             $("#password").css({display : "none"});

                                                                              $("#website").css({display : "none"});

          $("#email").css({display : "block",color : "red"});

        }
        else if(name1 == '' && website1 == '' && email1 != '' && password1 !='')
        {
           if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email1.length)
             {
				 if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
               $("#username").css({display : "block",color : "red"});
               $("#website").css({display : "block",color : "red"});
               $("#email").css({display : "block",color : "red"});
               $("#password").css({display : "none"});

             }
             else{
				 if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
                                                                       $("#password").css({display : "none"});
                                                          $("#email").css({display : "none"});

          $("#username").css({display : "block",color : "red"});
          $("#website").css({display : "block",color : "red"});
        }}
        else if( password1 == '' && email1 == '' && name1 != '' && website1 != '')
        {
			if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
                                                                                        $("#website").css({display : "none"});
                                                                                        $("#username").css({display : "none"});

          $("#password").css({display : "block",color : "red"});
          $("#email").css({display : "block",color : "red"});
        }
        else if(password1 == '' && website1 == '' && name1 != '' && email1 != '')
        {
          if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email1.length)
             {
				 if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
                    $("#username").css({display : "none"});
                    $("#website").css({display : "block",color : "red"});
               $("#email").css({display : "block",color : "red"});
                         $("#password").css({display : "block",color : "red"});
                          }
          else{
			  if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
                    $("#email").css({display : "none"});
                    $("#username").css({display : "none"});

          $("#website").css({display : "block",color : "red"});
          $("#password").css({display : "block",color : "red"});
     }   }
        else if (email1 == '' && website1 == '' && name1 != '' && password1 != '' )
        {
			if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
           $("#username").css({display : "none"});
                                                                                  $("#password").css({display : "none"});


            $("#email").css({display : "block",color : "red"});
                                                $("#website").css({display : "block",color : "red"});

        }
        else if(name1 == '' && password1 != '' && email1 != '' && website1 != ''){
          if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email1.length)
             {
				 if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }

                  $("#username").css({display : "block",color : "red"});
                  $("#email").css({display : "block",color : "red"});
                         
                   $("#password").css({display : "none"});
                    $("#website").css({display : "none"});
              }
              else
              {
				  if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
                $("#email").css({display : "none"});
                 $("#username").css({display : "block",color : "red"});
                 $("#password").css({display : "none"});
                    $("#website").css({display : "none"});
              }
              }
          

         else if(password1 == '' && email1 != '' && website1 != '' && name1 != '' )
        {
          if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email1.length)
             { if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
		 $("#email").css({display : "block",color : "red"});
                $("#username").css({display : "none"});
                    $("#website").css({display : "none"});
          $("#Password").css({display : "block",color : "red"});
        }
        else{
			if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
           $("#email").css({display : "none"});
           $("#username").css({display : "none"});
                    $("#website").css({display : "none"});
          $("#Password").css({display : "block",color : "red"});
        }}
        else if(email1 == '' && website1 != '' && name1 != '' && password1 != '' || atpos<1 || dotpos<atpos+2 || dotpos+2>=email1.length ) 
        {
			if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
          $("#username").css({display : "none"});
                    $("#website").css({display : "none"});
                    $("#password").css({display : "none"});
          $("#email").css({display : "block",color : "red"});

        }
        else if(website1 == '' && name1 != '' && password1 != '' && email1 != '')
        {
           if (atpos<1 || dotpos<atpos+2 || dotpos+2>=email1.length)
             {
				 if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
				 $("#email").css({display : "block",color : "red"});
            $("#password").css({display : "none"});
            $("#username").css({display : "none"});

          $("#website").css({display : "block",color : "red"});
        }
        else{
			if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
		{
		
			  if (firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' && dob1 == '' && phone1 == '' && lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' && dob1 == '' && phone1 == '' && firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && phone1 == '' && lastname1 == '' && dob1 != '')
        {
           
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 == '' && dob1 == '' && phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '' && dob1 != '')
        {
          $("#phone").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '' && lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                    $("#lastname").css({display : "none"});

                    $("#phone").css({display : "none"});

					$("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && phone1 == '' && dob1 != '' && lastname1 !='')
        {
         
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if( lastname1 == '' && dob1 == '' && firstname1 != '' && phone1 != '')
        {
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && phone1 == '' && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   
        else if (dob1 == '' && phone1 == '' && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' && lastname1 != '' && dob1 != '' && phone1 != ''){
          
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              
          

         else if(lastname1 == '' && dob1 != '' && phone1 != '' && firstname1 != '' )
        {
          
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           $("#lastname").css({display : "block",color : "red"});
        }
        else if(dob1 == '' && phone1 != '' && firstname1 != '' && lastname1 != '') 
        {
          $("#firstname").css({display : "none"});
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' && firstname1 != '' && lastname1 != '' && dob1 != '')
        {
           
          $("#dob").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
			
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
				if (firstname1 == '' && lastname1 == '' && dob1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && dob1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && dob1 != '')
        {
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && dob1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && dob1 != '')
        {
          
          $("#dob").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (dob1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "block",color : "red"});
		}
		else if (dob1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#dob").css({display : "none"});
		}
		} 
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(lastname1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && lastname1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#lastname").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && lastname1 !='')
        {
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(lastname1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && lastname1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#firstname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (firstname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(firstname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#firstname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && firstname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#firstname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && firstname1 != '' && dob1 != '' )
		{
		   $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
        
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '' && phone1 == '') 
		{
                            $("#lastname").css({display : "block",color : "red"});
                           $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});                                              
        }

        else if (lastname1 == '' && phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#phone").css({display : "block",color : "red"});
        } 
		else if(dob1 == '' && phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			$("#phone").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' && dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            $("#dob").css({display : "block",color : "red"});

        }
		else if(lastname1 == ''  && phone1 != '' && dob1 !='')
        {
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		   $("#lastname").css({display : "block",color : "red"});
          
        }
        
        else if(dob1 == ''  && lastname1 != '' && phone1 != '')
        {
          
          $("#phone").css({display : "none"});
          $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});
		}   
        else if (phone1 == ''  && lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           $("#phone").css({display : "block",color : "red"});
		}
		else if (phone1 != '' && lastname1 != '' && dob1 != '' )
		{
		   $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
		   $("#phone").css({display : "none"});
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (firstname1 == '' && dob1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && dob1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#lastname1').css('display') != 'none' )
        {
			if (firstname1 == '' && lastname1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#lastname").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && lastname1 != '' )
		{
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(lastname1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#lastname").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#lastname").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (firstname1 == '' && phone1 == '') 
		{
            $("#firstname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (firstname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#firstname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && firstname1 != '')
        {
            $("#firstname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (firstname1 != '' && phone1 != '' )
        {
           $("#firstname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#phone1').css('display') != 'none' )
        {
			if (lastname1 == '' && phone1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#phone").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && phone1 != '' )
		{
            $("#phone").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(phone1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#phone").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && phone1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#phone").css({display : "none"});
           
		}
		}
		else if($('#lastname1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (lastname1 == '' && dob1 == '') 
		{
            $("#lastname").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (lastname1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#lastname").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && lastname1 != '')
        {
            $("#lastname").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (lastname1 != '' && dob1 != '' )
        {
           $("#lastname").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		
		}
		else if($('#phone1').css('display') != 'none' && $('#dob1').css('display') != 'none' )
        {
			if (phone1 == '' && dob1 == '') 
		{
            $("#phone").css({display : "block",color : "red"})
			$("#dob").css({display : "block",color : "red"});
                                                         
        }

        else if (phone1 == '' && dob1 != '' )
		{
            $("#dob").css({display : "none"});
            $("#phone").css({display : "block",color : "red"});
            
        } 
		else if(dob1 == '' && phone1 != '')
        {
            $("#phone").css({display : "none"});
			$("#dob").css({display : "block",color : "red"});
			
        }
        
        else if (phone1 != '' && dob1 != '' )
        {
           $("#phone").css({display : "none"});
           $("#dob").css({display : "none"});
           
		}
		}
		else if($('#firstname1').css('display') != 'none')
                      {
                          if (firstname1 == '') 
                          {
                              $("#firstname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#firstname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#lastname1').css('display') != 'none')
                      {
                          if (lastname1 == '') 
                          {
                              $("#lastname").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#lastname").css({display : "none",color : "red"});
                          }
                      }
		else if($('#dob1').css('display') != 'none')
                      {
                          if (dob1 == '') 
                          {
                              $("#dob").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#dob").css({display : "none",color : "red"});
                          }
                      }
		else  if($('#phone1').css('display') != 'none')
                      {
                          if (phone1 == '') 
                          {
                              $("#phone").css({display : "block",color : "red"});
                          }
                          else
                          {
                              $("#phone").css({display : "none",color : "red"});
                          }
                      }
          $("#email").css({display : "none"});
           $("#password").css({display : "none"});
            $("#username").css({display : "none"});

          $("#website").css({display : "block",color : "red"});
        }
		}
		 
					  
		
		else {
          
          jQuery.ajax({
            type: "POST",
            url: ajaxurl,
            data: udata,

            
            success: function(response) {
              var n = response;
              
              if(n == 10) {
              
              $("#uns").css({display : "block",color : "red"});
              $("#su").css({display : "none",color : "red"});
              } else {
                 
              $("#uns").css({display : "none",color : "red"});
                $("#su").css({display : "block",color : "red"});
             }
             
              
              
            

            }
        
        });
      }                 

                       
                       
                      


                var udata = {action: "addCustomer",  'firstname1': firstname1 , 'lastname1' : lastname1 , 'dob1' : dob1 , 'phone1' : phone1 };
    var ajaurl="<?php echo admin_url( 'admin-ajax.php' ); ?>";
    
});

});
<?php 

?>


</script>
<style type="text/css">
  #username,#password,#email,#website,#mainform{
    display: none;
  
    
  }
  #su,#uns{
    display: none;
  }
</style>
    <h1>login</h1>
<div id="login" name="login">
<form name="login" action="" method="post" >
  <ul>
    <li><label for="usermail">Enter email or username</label>
    <input type="email" id="lname" name="usermail" placeholder="yourname@email.com or mysuperusername690" required>
    <div id="luser"> enter username</div>
    </li><br>
    <li><label for="password">Password</label>
    <input type="password" id="lpass" name="password" placeholder="password" required>
    <div id="lpassword"> enter password</div>
    </li><br>
    <li>
    <input type="button" name="login_btn" id="button1" value="Login"> </li>
    <input type="button" class="thickbox" alt="#TB_inline?height=500&;width=500&;inlineId=mainform" name="<?php echo $heading_qry ?>" id="reg_btn" value="sign_up"></li>
  </ul>
  <div id="lsu"> login successfully </div>
</form>
<div><br>


            <div id="mainform">
<div class="innerdiv">
<!-- Required Div Starts Here -->

<form action='' id="myForm" method='post' name="myForm">
<h3>Fill Your Information!</h3>
<table>
<tr id="firstname1">
<td>Firstname</td>
<td><input id="first" name='firstname' type='text'></td>

<td>
<div id='firstname'>  enter valid first name</div>
</td>
</tr>
<tr id="lastname1">
<td >Lastname</td>
<td><input id="last" name='lastname' type='text'></td>
<td>
<div id='lastname'> enter valid last name</div>
</td>
</tr>
<tr>
<td>Username</td>
<td><input id='username1' name='username' type='text'></td>

<td>
<div id='username'>  enter valid user name</div>
</td>
</tr>
<tr>
<td>Password</td>
<td><input id='password1' name='upassword' type='password'></td>
<td>
<div id='password'> enter password</div>
</td>
</tr>
<tr>
<td>Email</td>
<td><input id='email1' name='uemail' type='email'></td>
<td>
<div id='email'>enter valid email</div>
</td>
</tr>
<tr>
<td>website</td>
<td><input id='website1' name='website' type='text'></td>
<td>
<div id='website'> enter website</div>
</td>
</tr>
<!-- extra fields -->

<tr id="dob1">
<td>DOB</td>
<td><input id="date" name='dob' type='text'></td>

<td> 
<div id='dob'>enter valid date of birth</div>
</td>
</tr>
<tr id="phone1">
<td>Phone Number</td>
<td><input id="numb" name='phone' type='text'></td>

<td>
<div id='phone'> enter valid phone number</div>
</td>
</tr>
</table>
<input type="hidden" name="role" value="<?php echo $atts['role'] ?>" id = "role1">
<input type='button' value='<?php echo $button_text_qry ?>' id="r_button">
<div id="su"> user registered successfully </div>
<div id="uns"> user alerady registered </div>
</form>
</div>
</div>

        
    
<br>


<?php


echo "short code: [login role=' '] <br> e.g:[login role='author']";


/*if (isset($_POST['login_btn'])) {
  $password_login = md5($_POST['password']);  
  $usermail = $_POST['usermail'];

 $login = $wpdb->get_results("SELECT * FROM wp_users WHERE user_email = '".$usermail."' or user_login = '".$usermail."' and user_pass= '".$password_login."'  ");

    
   if($wpdb->num_rows > 0) // if uname/pass correct it returns must be 1 row
   {
   
     $rol = $wpdb->get_var("SELECT user_role FROM wp_user WHERE user_email = '".$usermail."' or user_login = '".$usermail."' and user_pass= '".$password_login."' ");
     $uid = $wpdb->get_var("SELECT id FROM wp_users WHERE user_email = '".$usermail."' or user_login = '".$usermail."' and user_pass= '".$password_login."'");
     $uid2=get_metadata('user',$uid,'wp_capabilities');
      print_r($uid2);
      
     /*if ($rol == 'administrator' || $rol == 'super admin' || $rol == 'editor' || $rol == 'author' || $rol == 'contributor' || $rol == 'subscriber') {
         echo $rol;
         //get_role($rol);
     }*/
   //if(wp_check_password($password_login,wp_hash_password($login['passwordsignup'])))
   //{
    
  /*  echo "login successfully";
   }
    else 
    {
    
    echo "invalid user";
    }
    */
}
add_action('muplugins_loaded', 'login');
//add_action('muplugins_loaded', 'users' );
add_shortcode('signup', 'login');
  
 //add_shortcode('signup', 'users');
 
 global $jal_db_version;
$jal_db_version = '1.0';

function jal_install() {
    global $wpdb; 
    global $jal_db_version;
	$alter_table = $wpdb->prefix .'extra_fields';

    $table_name = $wpdb->prefix .'save_changes';
    $table_fields = $wpdb->prefix.'fields';

    
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      post_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        heading varchar(255),
        button varchar(255) ,
        
        PRIMARY KEY  (id) 
    ) $charset_collate;";
    $sql2 = "CREATE TABLE $table_fields (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      post_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        fields varchar(255),
        
        PRIMARY KEY  (id) 
    ) $charset_collate;";
	$sql3 = "CREATE TABLE $alter_table (
      id mediumint(9) NOT NULL AUTO_INCREMENT,
      post_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        firstname varchar(255),
        lastname varchar(255) ,
        dob varchar(255),
        phone varchar(255) ,
		user_id mediumint(9),
        
        PRIMARY KEY  (id) 
    ) $charset_collate;";
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
    dbDelta( $sql2 );
	dbDelta( $sql3 );
    add_option( 'jal_db_version', $jal_db_version );
}
register_activation_hook( __FILE__, 'jal_install' );

?>




