

 
 if (firstname1 == '' || lastname1 == '' || dob1 == '' || phone1 == '' ) {
                            $("#firstname").css({display : "block",color : "red"});
                           $("#lastname").css({display : "block",color : "red"});
                            $("#dob").css({display : "block",color : "red"});
                            $("#phone").css({display : "block",color : "red"});

                                               
        }

        else if (firstname1 == '' || dob1 == '' || phone1 == '' || lastname1 != '' ){
                                         $("#lastname").css({display : "none"});

                 
                            $("#firstname").css({display : "block",color : "red"});
                                      $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});



          

        } else if(lastname1 == '' || dob1 == '' || phone1 == '' || firstname1 != '')
        {
                                      $("#firstname").css({display : "none"});

           $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' || phone1 == '' || lastname1 == '' || dob1 != '')
        {
            if (atpos<1 || dotpos<atpos+2 || dotpos+2>=dob1.length)
            {
              $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});
                      $("#dob").css({display : "block",color : "red"});

            }
            else{
                        $("#dob").css({display : "none"});

                      $("#firstname").css({display : "block",color : "red"});
                      $("#phone").css({display : "block",color : "red"});
                      $("#lastname").css({display : "block",color : "red"});

                   } }
        else if(firstname1 == '' || lastname1 == '' || dob1 == '' || phone1 != '')
        {
                                                $("#phone").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(firstname1 == '' || lastname1 == '' || phone1 != '' || dob1 != '')
        {
          if (atpos<1 || dotpos<atpos+2 || dotpos+2>=dob1.length)
             {
              $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
          $("#phone").css({display : "none"});
             }
             else{
                                                          $("#phone").css({display : "none"});
                                                          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
        }}
        else if(firstname1 == '' || dob1 == '' || phone1 != '' || lastname1 != '' )
        {
                    $("#firstname").css({display : "block",color : "red"});
                                                             $("#lastname").css({display : "none"});

                                                                              $("#phone").css({display : "none"});

          $("#dob").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' || phone1 == '' || dob1 != '' || lastname1 !='')
        {
           if (atpos<1 || dotpos<atpos+2 || dotpos+2>=dob1.length)
             {
               $("#firstname").css({display : "block",color : "red"});
               $("#phone").css({display : "block",color : "red"});
               $("#dob").css({display : "block",color : "red"});
               $("#lastname").css({display : "none"});

             }
             else{
                                                                       $("#lastname").css({display : "none"});
                                                          $("#dob").css({display : "none"});

          $("#firstname").css({display : "block",color : "red"});
          $("#phone").css({display : "block",color : "red"});
        }}
        else if( lastname1 == '' || dob1 == '' || firstname1 != '' || phone1 != '')
        {
                                                                                        $("#phone").css({display : "none"});
                                                                                        $("#firstname").css({display : "none"});

          $("#lastname").css({display : "block",color : "red"});
          $("#dob").css({display : "block",color : "red"});
        }
        else if(lastname1 == '' || phone1 == '' || firstname1 != '' || dob1 != '')
        {
          if (atpos<1 || dotpos<atpos+2 || dotpos+2>=dob1.length)
             {
                    $("#firstname").css({display : "none"});
                    $("#phone").css({display : "block",color : "red"});
               $("#dob").css({display : "block",color : "red"});
                         $("#lastname").css({display : "block",color : "red"});
                          }
          else{
                    $("#dob").css({display : "none"});
                    $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
          $("#lastname").css({display : "block",color : "red"});
     }   }
        else if (dob1 == '' || phone1 == '' || firstname1 != '' || lastname1 != '' )
        {
           $("#firstname").css({display : "none"});
                                                                                  $("#lastname").css({display : "none"});


            $("#dob").css({display : "block",color : "red"});
                                                $("#phone").css({display : "block",color : "red"});

        }
        else if(firstname1 == '' || lastname1 != '' || dob1 != '' || phone1 != ''){
          if (atpos<1 || dotpos<atpos+2 || dotpos+2>=dob1.length)
             {

                  $("#firstname").css({display : "block",color : "red"});
                  $("#dob").css({display : "block",color : "red"});
                         
                   $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              else
              {
                $("#dob").css({display : "none"});
                 $("#firstname").css({display : "block",color : "red"});
                 $("#lastname").css({display : "none"});
                    $("#phone").css({display : "none"});
              }
              }
          

         else if(lastname1 == '' || dob1 != '' || phone1 != '' || firstname1 != '' )
        {
          if (atpos<1 || dotpos<atpos+2 || dotpos+2>=dob1.length)
             {  $("#dob").css({display : "block",color : "red"});
                $("#firstname").css({display : "none"});
                    $("#phone").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
        }
        else{
           $("#dob").css({display : "none"});
           $("#firstname").css({display : "none"});
                    $("#phone").css({display : "none"});
          $("#lastname").css({display : "block",color : "red"});
        }}
        else if(dob1 == '' || phone1 != '' || firstname1 != '' || lastname1 != '' || atpos<1 || dotpos<atpos+2 || dotpos+2>=dob1.length ) 
        {
          $("#firstname").css({display : "none"});
                    $("#phone").css({display : "none"});
                    $("#lastname").css({display : "none"});
          $("#dob").css({display : "block",color : "red"});

        }
        else if(phone1 == '' || firstname1 != '' || lastname1 != '' || dob1 != '')
        {
           if (atpos<1 || dotpos<atpos+2 || dotpos+2>=dob1.length)
             {  $("#dob").css({display : "block",color : "red"});
            $("#lastname").css({display : "none"});
            $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }
        else{
          $("#dob").css({display : "none"});
           $("#lastname").css({display : "none"});
            $("#firstname").css({display : "none"});

          $("#phone").css({display : "block",color : "red"});
        }}