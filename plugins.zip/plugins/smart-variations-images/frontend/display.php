<?php
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

global $post, $woocommerce, $product;
?>
<div class="whitespacesvi">&nbsp;</div>
<div id="woosvi_strap" class="images woosvi_images">
    <div class="sivmainloader"><?php _e('Loading', 'woocommerce-svi'); ?>...</div>
    <div id="woosvimain" class="svihidden"></div>
    <div id="woosvithumbs" class="svihidden"></div>
</div>