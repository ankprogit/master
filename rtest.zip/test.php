<?php 
$str="dag@kreativinsikt.se:Stockholm66";
$my=base64_decode($str);
 $code="Basic ".$my;
$url="https://apitest.billecta.com/v1/authentication/apiauthenticate";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.4322)');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
curl_setopt($ch, CURLOPT_TIMEOUT, 5);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    "Authorization:Basic $my",
    'Content-Length:0',
	'Accept: application/json'
    ));
//$data = curl_exec($ch);
//print_r($data);
//$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
//curl_close($ch);
/*curl -X "POST"  -H "Content-Length:0" -H "Authorization: SecureToken NVVpczU0RW1RLzlqSnRHaFFvUzhLOXhIUnNNWFFoWmc9PQ==" -H "Accept: application/json"*/

 
 function CurlSendPostRequest2($url,$request)
    {
        $authentication = base64_encode("dag@kreativinsikt.se:Stockholm66");

        $ch = curl_init($url);
        $options = array(
                CURLOPT_RETURNTRANSFER => false,         // return web page
                CURLOPT_HEADER         => false,        // don't return headers
                CURLOPT_FOLLOWLOCATION => false,         // follow redirects
               // CURLOPT_ENCODING       => "utf-8",           // handle all encodings
                CURLOPT_AUTOREFERER    => true,         // set referer on redirect
                CURLOPT_CONNECTTIMEOUT => 20,          // timeout on connect
                CURLOPT_TIMEOUT        => 20,          // timeout on response
                CURLOPT_POST            => 1,            // i am sending post data
                CURLOPT_POSTFIELDS     => $request,    // this are my post vars
                CURLOPT_SSL_VERIFYHOST => 0,            // don't verify ssl
                CURLOPT_SSL_VERIFYPEER => false,        //
                CURLOPT_VERBOSE        => 1,
                CURLOPT_HTTPHEADER     => array(
                    "Authorization: Basic $authentication",
                    "Content-Type: application/json",
					"Content-Length:0"
                )

        );
		print_r($options);

        curl_setopt_array($ch,$options);
        $data = curl_exec($ch);
	
        $curl_errno = curl_errno($ch);
        $curl_error = curl_error($ch);
        //echo $curl_errno;
        //echo $curl_error;
        curl_close($ch);
        return $data;
    }
$url="https://apitest.billecta.com/v1/authentication/apiauthenticate";
//$output=CurlSendPostRequest2($url,$request=array());
print_r($output);

 function CurlSendPostRequest1($url,$request)
    {
        $authentication = base64_encode("vCE46oNYQmiGxIW0MBiiOeR35vmcTSiWgJ5JLlqA8sDFS4ssfdNb/vYYVJq/IbGc161bZmm8i1OzbIEw4v/oNA==");

        $ch = curl_init($url);
        $options = array(
                CURLOPT_RETURNTRANSFER => false,         // return web page
                CURLOPT_HEADER         => false,        // don't return headers
                CURLOPT_FOLLOWLOCATION => false,         // follow redirects
               // CURLOPT_ENCODING       => "utf-8",           // handle all encodings
                CURLOPT_AUTOREFERER    => true,         // set referer on redirect
                CURLOPT_CONNECTTIMEOUT => 20,          // timeout on connect
                CURLOPT_TIMEOUT        => 20,          // timeout on response
                CURLOPT_POST            => 1,            // i am sending post data
                CURLOPT_POSTFIELDS     => $request,    // this are my post vars
                CURLOPT_SSL_VERIFYHOST => 0,            // don't verify ssl
                CURLOPT_SSL_VERIFYPEER => false,        //
                CURLOPT_VERBOSE        => 1,
                CURLOPT_HTTPHEADER     => array(
                    "Authorization: SecureToken $authentication",
                    "Content-Type: application/json",
					"Content-Length:0"
                )

        );
		print_r($options);

        curl_setopt_array($ch,$options);
        $data = curl_exec($ch);
	
        $curl_errno = curl_errno($ch);
        $curl_error = curl_error($ch);
        //echo $curl_errno;
        //echo $curl_error;
        curl_close($ch);
        return $data;
    }
$url="https://apitest.billecta.com/v1/authentication/apiauthenticate";
$output=CurlSendPostRequest1($url,$request=array());
print_r($output); 
json_encode($output);
function CurlSendPostRequest($url,$request)
    {
        $authentication = base64_encode("V9ymLSzWXONAl49H2Azl3TsUveSzGZMc2ZzIyD3hG68zxi9+XqMWrup375Tt4ZiyLrAZHn7djLLqp+/nGjd+Sw==");

        $ch = curl_init($url);
        $options = array(
                CURLOPT_RETURNTRANSFER => false,         // return web page
                CURLOPT_HEADER         => false,        // don't return headers
                CURLOPT_FOLLOWLOCATION => false,         // follow redirects
               // CURLOPT_ENCODING       => "utf-8",           // handle all encodings
                CURLOPT_AUTOREFERER    => true,         // set referer on redirect
                CURLOPT_CONNECTTIMEOUT => 20,          // timeout on connect
                CURLOPT_TIMEOUT        => 20,          // timeout on response
                CURLOPT_POST            => 1,            // i am sending post data
                CURLOPT_POSTFIELDS     => $request,    // this are my post vars
                CURLOPT_SSL_VERIFYHOST => 0,            // don't verify ssl
                CURLOPT_SSL_VERIFYPEER => false,        //
                CURLOPT_VERBOSE        => 1,
                CURLOPT_HTTPHEADER     => array(
				"Authorization: SecureToken $authentication",
                    "Content-Type: application/json",
					"Content-Length:0",
                    "DebtorPublicId :cb27a5a0-fee2-4ff1-a0f3-0a1fd3e54792",
  "CreditorPublicId :985966ad-a129-434b-a5bd-fe7ceed7af12",
  "DebtorExternalId:null",
  "OrgNo:556888-5645",
  "Name:Jenny Doe",
  "Address:Address 1",
  "Address2: null",
  "ZipCode:11175",
  "City:Stockholm",
  "CountryCode:SE",
  "Phone:null",
  "Email:invoice@billecta.com",
  "ContactName:Jenny Doe",
  "ContactEmail:Jenny.Doe@billecta.com",
  "VatNumber:SE556888564501",
  "DebtorNo:null",
  "GLN: null",
  "IsActive: null",
  "Intermediator: null",
  "EInvoiceBank: null",
  "Notes: null",
  "DebtorSelfInvoiceInfo:null",
  "DefaultActionConfig:null",
  "Autogiro:null",
  "Created:2017-01-01 00:00:00+01:00"
                )

        );
		print_r($options);

        curl_setopt_array($ch,$options);
        $data = curl_exec($ch);
	
        $curl_errno = curl_errno($ch);
        $curl_error = curl_error($ch);
        //echo $curl_errno;
        //echo $curl_error;
        curl_close($ch);
        return $data;
    }
$url="https://apitest.billecta.com//v1/debtors/debtor";
$request=array( "DebtorPublicId"=> "cb27a5a0-fee2-4ff1-a0f3-0a1fd3e54792",
  "CreditorPublicId"=> "985966ad-a129-434b-a5bd-fe7ceed7af12",
  "DebtorExternalId"=> null,
  "OrgNo"=> "556888-5645",
  "Name"=> "Jenny Doe",
  "Address"=>"Address 1",
  "Address2"=> null,
  "ZipCode"=> "11175",
  "City"=> "Stockholm",
  "CountryCode"=> "SE",
  "Phone"=> null,
  "Email"=> "invoice@billecta.com",
  "ContactName"=> "Jenny Doe",
  "ContactEmail"=> "Jenny.Doe@billecta.com",
  "VatNumber"=> "SE556888564501",
  "DebtorNo"=> null,
  "GLN"=> null,
  "IsActive"=> null,
  "Intermediator"=> null,
  "EInvoiceBank"=> null,
  "Notes"=> null,
  "DebtorSelfInvoiceInfo"=> null,
  "DefaultActionConfig"=> null,
  "Autogiro"=> null,
  "Created"=> "0001-01-01 00:00:00+01:00");
$output=CurlSendPostRequest($url,$request);
print_r($output);

?>