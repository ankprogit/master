<?php  /*
Template Name: contact_us
*/
?>
<?php get_header();?>
<div class="container contact-page-outter">
	<div class="inner">
  <div class="contact-form-outter">
	<h2>Feedback Form</h2>
	<?php echo do_shortcode('[contact-form-7 id="186" title="Contact form 1"]'); ?>
  </div>
  <div class="contact-details">
				<h2>Contact Details</h2>
					<ul>
						<li>
							<h3>Address</h3>
							<p>267 Park Avenue New York, NY 90210</p>
						</li>
						<li>
							<h3>We Are Open</h3>
							<p>Open hours: 8.00-18.00 Mon-Sat</p>
						</li>
						<li>
							<h3>Phone Number</h3>
							<a href="#">(123) 45678910,  (123) 67886756 </a>
						</li>
						<li>
							<h3>Email</h3>
							<a href="#" action="mailto:mailto:info@demolink.org">info@watchstore.org</a>
						</li>
						<li>
							<h3>Social Links</h3>
							<ul class="social-links">
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
							</ul>
						</li>
					</ul>
			</div>
		</div>
</div>
<?php if (isset($_POST["submit"])) {
	global $jal_db_version;
$jal_db_version = '1.0';

function jal_install() {
    global $wpdb; 
    global $jal_db_version;
    $main_table1 = $wpdb->prefix.'contact_us';
    $charset_collate = $wpdb->get_charset_collate();
 
    $main_sql = "CREATE TABLE $main_table1 (
    	id mediumint(9) NOT NULL AUTO_INCREMENT,
    	post_time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
    	name varchar(255) ,
    	email varchar(255),
    	subject varchar(255),
        PRIMARY KEY  (slider_id) 
    ) $charset_collate;";


    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
   
    
    dbDelta( $main_sql);

    add_option( 'jal_db_version', $jal_db_version );
}
register_activation_hook( __FILE__, 'jal_install' );
} ?>
<?php get_footer(); ?>