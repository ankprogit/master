<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>

		<div id="footer">
<div class="top-footer">
    <div class="inner">
        <div class="left-footer foo">
            <?php if (   is_active_sidebar( 'first-footer-widget-area'  )){ 
           dynamic_sidebar('first-footer-widget-area'); } ?>
            <div class="footer-social">
                <a target="_blank" href="www.facebook.com"><i class="fa fa-facebook"></i></a>
                <a target="_blank" href="www.twitter.com"><i class="fa fa-twitter"></i></a>
                <a target="_blank" href="www.youtube.com"><i class="fa fa-youtube"></i></a>
                <a target="_blank" href="www.linkedin.com"><i class="fa fa-linkedin"></i></a>
            </div>
        </div>
        
        <div class="foo footer-menu">
            <h2 class="footer-wid-title">User Navigation </h2>
            <ul>
                 <?php wp_nav_menu(array('menu' => 'footer_1')); ?>
            </ul>                        
        </div>
        
        <div class="foo footer-menu">
            <h2 class="footer-wid-title">Categories</h2>
            <ul>
                <?php wp_nav_menu(array('menu' => 'footer_2')); ?>
                
            </ul>                        
        </div>
        
        <div class="foo footer-newsletter">
            <?php if (   is_active_sidebar( 'fourth-footer-widget-area'  )){ 
           dynamic_sidebar('fourth-footer-widget-area'); } ?>
            <div class="newsletter-form">
                <form action="#">
                    <input type="email" placeholder="Type your email">
                    <input type="submit" value="Subscribe">
                </form>
            </div>
        </div>
        
    </div>
</div>
<div class="bottom-footer">
    <div class="inner">
        <p>  &copy; <?php echo date("Y"); echo " "; echo bloginfo('name'); ?>  
          </p>
    </div>
</div>
</div>
<!--footer-->

</div>

</body>
</html>

