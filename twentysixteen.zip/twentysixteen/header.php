<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script >
	
$(document).ready(function(){     
  
  $(".click-btn").click(function(){
    

    $(this).parent().find(".toggle-nav").css('display','block !important');
  });

});
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>WebDesk Desigenr</title>


<link href="<?php bloginfo('template_url'); ?>/style/css.css" type="text/css" rel="stylesheet" />
<link href="<?php bloginfo('template_url'); ?>/font/stylesheet.css" type="text/css" rel="stylesheet" />
<link href="https://fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700|Saira+Extra+Condensed:100,200,300,400,500,600,700,800,900" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300i,700" rel="stylesheet"> 
<link href="<?php bloginfo('template_url'); ?>/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=PT+Sans:400,700" rel="stylesheet">
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/test.js"></script> 

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php //do_action( 'woocommerce_before_single_product' ); ?> 
 <meta name="viewport" content="width=device-width">
<div id="wrapper">
<div id="header" class="header-main">
	<div class="upper-header">
        	<div class="inner">
				<div class="left-head">
            <ul>
           <?php
             wp_nav_menu(array('menu' => 'top_menu'));
			?>
            </ul>
                </div>
                <div class="right-head">
                    	<form>
                            <?php get_product_search_form();?>
							
							<?php
							 wp_nav_menu(array('menu' => 'top_menu_cart'));
							?>
							
                        </form>
                </div>
		   </div><!--inner-->
      </div><!--upper-->
      <div class="center-head">
           <div class="inner">
               <div class="left-center-head">
                   <div class="logo">
                        	<a href="<?php echo home_url(); ?>"><?php
      
$custom_logo_id = get_theme_mod( 'custom_logo' );
$logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
if ( has_custom_logo() ) {
        echo '<img src="'.esc_url( $logo[0] ).'">';
} 
?></a>
                   </div>
                   
               </div>
           </div><!--inner-->
      </div><!--center-->
      
      <div class="subnav">
           <div class="inner">
           <button class="click-btn" type="button"><i class="fa fa-align-justify"></i></button>
                <ul class="toggle-nav">
                   <?php wp_nav_menu(array('menu' => 'main_menu')); ?>
                  </ul>
                
                </div>
        </div>
</div>
