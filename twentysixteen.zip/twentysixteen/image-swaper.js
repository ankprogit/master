
jQuery(document).ready(function($) {
 	var product_main_image = $( 'a.woocommerce-main-image' ).attr( 'href' );
 	$(".thumbnails a").hover(
 		function(){
     				var product_full_image = $(this).attr('href');
     				$('.woocommerce-main-image img').attr('srcset', product_full_image);
   				},
   
   		function(){
     				$('.woocommerce-main-image img').attr('src', product_main_image);
   				}
 	);
} );