<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */

get_header(); 
global $woocommerce;
?>

	<div class="slider">
        		<?php echo do_shortcode("[wowslider id='9']"); ?>
</div>
<!--slider-->

<div class="otherddetails">
    <div class="inner">
        <div class="inner-detail">
            <?php $id=68;
$post=get_post($id);
$content=apply_filters('the_content',$post->post_content);

echo "$content";
echo get_the_post_thumbnail( $id, the_post_thumbnail( 'large','style=max-width:100%;height:auto;'), array( 'class' => 'alignright' ) );
?>
        </div>
    </div>
</div>
<!--other-details-->

<div class="watch-list">
<div class="inner">
            	<div class="main-watch">
                
             <span class="product-heading"><h1>Top Rated Products</h1><a href="<?php echo get_permalink(172); ?>" class="see-all">See all</a> 
            </span><ul>
            	
		            <?php
						$args = array(
						    'post_type' => 'product',
						    'meta_key' => ' _wc_average_rating',
						    'orderby' => 'meta_value_num',
						    'posts_per_page' => 4,
						);
						$loop = new WP_Query( $args );
						while ( $loop->have_posts() ) : $loop->the_post(); 
							global $product; ?>
					<li>
                
                    <a id="id-<?php the_id(); ?>" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="pro-title">
                    		<?php the_title(); ?></a>
                    		<div class="thumbnail">
					<?php $_product = wc_get_product( get_the_id() );
					
					if (has_post_thumbnail( $loop->post->ID )) 
					{
					       ?> <a href="<?php the_permalink(); ?>"> <?php echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); ?> </a> 
					       
							<div class="price">
							<?php
					    	 echo $product->get_price_html(); ?>
					    	 <div class="product-rating ratingstar">
							    <?php if ($average = $product->get_average_rating()) :
							        
							        $val = round($average);
							        for ($i=1; $i <= 5 ; $i++) { 
							        	if($i<=$val){
							         	echo '<i class="fa fa-star orange"> </i>'; 
							         	}else{echo '<i class="fa fa-star "> </i>'; }
							         }
							        // echo $Product->get_review_count(200); ?>
							    <?php endif; ?>
							</div>
					    	 </div> 

					    	 
					    	
					    	 <div class="cart cart_ajax addcart" ><?php woocommerce_template_loop_add_to_cart(); ?> </div> 
					    	  <div class="cart cart_ajax wait"><img src="<?php bloginfo('template_url'); ?>/img/200_s.gif"></div>
					    	  <div class="cart cart_ajax viewcart"><a href="<?php echo $woocommerce->cart->get_cart_url(); ?>" >view cart </a> </div> </div> 
					    	 <?php
					 }       else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="product placeholder Image" width="65px" height="115px" />'; ?>

					
					
                </li>
                
                <?php endwhile; ?>
					<?php wp_reset_query(); ?>
           </ul> 
    </div>
					
                
               
            </div>
</div>
<!--watchlist-->



<div class="feature-product">
<div class="inner">
        <div class="main-watch">
             <span class="product-heading"><h1>Featured Products</h1><a href="<?php echo get_permalink(87); ?>" class="see-all">See all</a> 
            </span><ul>
      
    
        <?php
        $args = array(
    'posts_per_page'   => 4,
    'orderby'          => 'rand',
    'post_type'        => 'product',
    'meta_query'  => array(
        'key'     => '_featured',
        'value'   => 'yes'
    )
);

$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post(); global $product; ?>

<li>
    <a href="<?php echo the_permalink(); ?>" class="pro-title"><?php the_title(); ?></a>
        <div class="thumbnail">
        <?php  $_product = wc_get_product( get_the_id() ); 
        if (has_post_thumbnail( $loop->post->ID )) {
					     ?> <a href="<?php the_permalink(); ?>"> <?php echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); ?> </a>

					       
				<div class="price">
				<?php  echo $product->get_price_html();	?>
				<div class="product-rating ratingstar">
							    <?php if ($average = $product->get_average_rating()) :
							        
							        $val = round($average);
							        for ($i=1; $i <= 5 ; $i++) { 
							        	if($i<=$val){
							         	echo '<i class="fa fa-star orange"> </i>'; 
							         	}else{echo '<i class="fa fa-star "> </i>'; }
							         } ?>
							    <?php endif; ?>
							</div>
					</div> 
					<div class="cart cart_ajax addcart" ><?php woocommerce_template_loop_add_to_cart(); ?> </div> 
				    <div class="cart cart_ajax wait"><img src="<?php bloginfo('template_url'); ?>/img/200_s.gif"></div>
					<div class="cart cart_ajax viewcart"><a href="<?php echo $woocommerce->cart->get_cart_url(); ?>" >view cart </a> </div>
					</div> <?php }
					        else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="product placeholder Image" width="65px" height="115px" />'; ?>

   
</li>

<?php endwhile;
wp_reset_query(); ?>

        </ul>
    </div>
       
      


        


       
       <div class="main-watch">
            <span class="product-heading"><h1>Popular Products</h1><a href="<?php echo get_permalink(95); ?>" class="see-all">See all</a> 
            </span><ul>
            	
		            <?php
						$args = array(
						    'post_type' => 'product',
						    'meta_key' => 'total_sales',
						    'orderby' => 'meta_value_num',
						    'posts_per_page' => 4,
						);
						$loop = new WP_Query( $args );
						while ( $loop->have_posts() ) : $loop->the_post(); 
							global $product; ?>
					<li>
                
                    <a id="id-<?php the_id(); ?>" href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="pro-title">
                    		<?php the_title(); ?></a>
                    		<div class="thumbnail">
					<?php $_product = wc_get_product( get_the_id() );
					
					if (has_post_thumbnail( $loop->post->ID )) 
					{
					       ?> <a href="<?php the_permalink(); ?>"> <?php echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); ?> </a> 
					       
							<div class="price">
							<?php
					    	 echo $product->get_price_html();
					    	 ?>
					    	 <div class="product-rating ratingstar">
							    <?php if ($average = $product->get_average_rating()) :
							        
							        $val = round($average);
							        for ($i=1; $i <= 5 ; $i++) { 
							        	if($i<=$val){
							         	echo '<i class="fa fa-star orange"> </i>'; 
							         	}else{echo '<i class="fa fa-star "> </i>'; }
							         } 
							         
							     endif; ?>
							</div> 
					    	 </div>
					    	 	
					    	  <div class="cart cart_ajax addcart" ><?php woocommerce_template_loop_add_to_cart(); ?> </div> 
					    	  <div class="cart cart_ajax wait"><img src="<?php bloginfo('template_url'); ?>/img/200_s.gif"></div>
					    	  <div class="cart cart_ajax viewcart"><a href="<?php echo $woocommerce->cart->get_cart_url(); ?>" >view cart </a> </div></div>
					    	   <?php 
					    	
					 }       else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="product placeholder Image" width="65px" height="115px" />'; ?>

					
					
                </li>
                
                <?php endwhile; ?>
					<?php wp_reset_query(); ?>
					
            </ul> 
    
</div>
</div>
</div>
<!--feature adn products-->

<div class="top-brand">
<div class="inner">                	
    
            <?php
				$id=102;
				$post=get_post($id);
				$content=apply_filters('the_content',$post->post_content);

				echo "$content";
				echo get_the_post_thumbnail( $id, the_post_thumbnail());

			?>
       
    </div>
    </div>
</div>


<?php get_footer(); ?>
