jQuery(document).ready(function(){     
  
  $(".click-btn").click(function(){
    $(".toggle-nav").toggle();
  });

});