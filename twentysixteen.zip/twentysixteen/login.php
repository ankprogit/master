<?php  /*
Template Name: login
*/
?>
<?php get_header(); ?>
<?php echo  do_shortcode("[login-1]"); ?>
<?php get_footer(); ?>