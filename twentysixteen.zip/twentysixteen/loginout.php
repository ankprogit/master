<?php  /*
Template Name: loginout
*/
?>
<?php 
 if (is_user_logged_in()) {
         
         $items .= '<li><a href="'. wp_logout_url() .'">Log Out</a></li>';
      	 echo $items;
      } else {
         $items .= '<li><a href="'. wp_login_url(get_permalink()) .'">Log In</a></li>';
      		echo $items;
      }
?>