<?php  /*
Template Name: most_purchased_product
*/
?>
<?php
get_header(); 
?>
<div class="feature-product">
<div class="inner">
 <div class="product">
            <h1><span>Top Rated Products</span></h1>
            <ul>
            	
		            <?php
						$args = array(
						    'post_type' => 'product',
						    'meta_key' => 'total_sales',
						    'orderby' => 'meta_value_num',
						    'posts_per_page' => 12,
						);
						$loop = new WP_Query( $args );
						while ( $loop->have_posts() ) : $loop->the_post(); 
							global $product; ?>
					<li>
                
                   <a href="<?php echo get_permalink( $loop->post->ID ) ?>" title="<?php echo esc_attr($loop->post->post_title ? $loop->post->post_title : $loop->post->ID); ?>">
                    		<?php the_title(); ?>
                    		<div class="thumbnail">
					<?php $_product = wc_get_product( get_the_id() );
					
					if (has_post_thumbnail( $loop->post->ID )) 
					{
					       ?> <a href="<?php echo get_permalink( $loop->post->ID ) ?>"> <?php echo get_the_post_thumbnail($loop->post->ID, 'shop_catalog'); ?> </a> 
					       
							<div class="price">
							<?php
					    	 echo $product->get_price_html();
					    	 ?> </div> <?php woocommerce_template_loop_add_to_cart(); ?></div></a> <?php
					 }       else echo '<img src="'.woocommerce_placeholder_img_src().'" alt="product placeholder Image" width="65px" height="115px" />'; ?>

				
                </li>
                
                <?php endwhile; ?>
					<?php wp_reset_query(); ?>
            </ul> 
    </div>
</div>
</div>
<?php 
get_footer();
?>