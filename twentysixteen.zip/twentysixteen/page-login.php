<?php  /*
Template Name: page-login
*/
?>
<?php get_header(); ?>

<div class="login-form">
<div class="loginform1">
<div class="banner"><img src="<?php bloginfo('template_url'); ?>/img/banner.jpg"></div>
<?php
$args = array(
    'redirect' => get_permalink(8), 
    'id_username' => 'user',
    'id_password' => 'pass',
   ) 
;?>
<?php wp_login_form( $args );
?>
<a href="<?php echo get_permalink(296); ?>" class="signup-link">Sign Up</a>
</div></div>
<?php
$login  = (isset($_GET['login']) ) ? $_GET['login'] : 0;
if ( $login === "failed" ) {
  echo '<p class="login-msg"><strong>ERROR:</strong> Invalid username and/or password.</p>';
} elseif ( $login === "empty" ) {
  echo '<p class="login-msg"><strong>ERROR:</strong> Username and/or Password is empty.</p>';
} elseif ( $login === "false" ) {
  echo '<p class="login-msg"><strong>ERROR:</strong> You are logged out.</p>';
}
?>
<?php get_footer(); ?>