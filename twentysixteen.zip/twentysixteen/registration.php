<?php  /*
Template Name: registration
*/
?>
<?php get_header(); ?>
<?php echo do_shortcode("[signup role='Subscriber']"); ?>
<?php get_footer(); ?>