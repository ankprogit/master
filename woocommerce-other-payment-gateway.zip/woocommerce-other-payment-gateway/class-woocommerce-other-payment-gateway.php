<?php 

class WC_Billecta_Payment_Gateway extends WC_Payment_Gateway{

	public function __construct(){
		$this->id = 'billecta_payment';
		$this->method_title = __('Billecta Payment','woocommerce-billecta-payment-gateway');
		$this->title = __('Billecta Payment','woocommerce-billecta-payment-gateway');
		$this->has_fields = true;
		$this->init_form_fields();
		$this->init_settings();
		$this->enabled = $this->get_option('enabled');
		$this->title = $this->get_option('title');
		$this->description = $this->get_option('description');
		add_action('woocommerce_update_options_payment_gateways_'.$this->id, array($this, 'process_admin_options'));
	}
	public function init_form_fields(){
				$this->form_fields = array(
					'enabled' => array(
					'title' 		=> __( 'Enable/Disable', 'woocommerce-billecta-payment-gateway' ),
					'type' 			=> 'checkbox',
					'label' 		=> __( 'Enable Custom Payment', 'woocommerce-billecta-payment-gateway' ),
					'default' 		=> 'yes'
					),
					'title' => array(
						'title' 		=> __( 'Plugin Title', 'woocommerce-billecta-payment-gateway' ),
						'type' 			=> 'text',
						'description' 	=> __( 'This controls the title', 'woocommerce-billecta-payment-gateway' ),
						'default'		=> __( 'Custom Payment', 'woocommerce-billecta-payment-gateway' ),
						'desc_tip'		=> true,
					),
					'description' => array(
						'title' => __( 'Customer Message', 'woocommerce-billecta-payment-gateway' ),
						'type' => 'textarea',
						'css' => 'width:500px;',
						'default' => 'None of the other payment options are suitable for you? please drop us a note about your favourable payment option and we will contact you as soon as possible.',
						'description' 	=> __( 'The message which you want it to appear to the customer in the checkout page.', 'woocommerce-billecta-payment-gateway' ),
					),
						'Full_payment' => array(
					'title' 		=> __( 'Full Payment', 'woocommerce-billecta-payment-gateway' ),
					'type' 			=> 'checkbox',
					'label' 		=> __( 'Full payment Enable Custom Payment', 'woocommerce-billecta-payment-gateway' ),
					'default' 		=> '0'
					),'inoice_fee' =>
  array(
  'title' 		=> __( 'invoice_fee', 'woocommerce-billecta-payment-gateway' ),


    'desc'    => __( 'This controls the position of the currency symbol.', 'woocommerce-billecta-payment-gateway' ),

    'id'      => 'woocommerce_currency_pos',

    'css'     => 'min-width:150px;',

    'std'     => 'No Fee', // WooCommerce < 2.0

    'default' => 'no', // WooCommerce >= 2.0

    'type'    => 'select',
	'label' 		=> __( 'Invoice fee', 'woocommerce-billecta-payment-gateway' ),

    'options' => array(
 '0'        => __( 'no fee', 'woocommerce-billecta-payment-gateway' ),
      '5'        => __( '5', 'woocommerce-billecta-payment-gateway' ),

      '10'       => __( '10', 'woocommerce-billecta-payment-gateway' ),

      '15'  => __( '15', 'woocommerce-billecta-payment-gateway' ),

      '20' => __( '20', 'woocommerce-billecta-payment-gateway' )

    ),

    'desc_tip' =>  true,

  ),'partial_payment' => array(
					'title' 		=> __( 'Partial Payment', 'woocommerce-billecta-payment-gateway' ),
					'type' 			=> 'checkbox',
					
					'label' 		=> __( 'Partial payment Enable Custom Payment', 'woocommerce-billecta-payment-gateway' ),
					'default' 		=> 'no'
					),
	'num_invoices' => array(
					'title' 		=> __( 'Number Invoices', 'woocommerce-billecta-payment-gateway' ),
					'type' 			=> 'select',
					 'options' => array(
 '2'        => __( '2', 'woocommerce-billecta-payment-gateway' ),
      '3'        => __( '3', 'woocommerce-billecta-payment-gateway' ),

      '4'       => __( '4', 'woocommerce-billecta-payment-gateway' ),

      '5'  => __( '5', 'woocommerce-billecta-payment-gateway' ),

      '6' => __( '6', 'woocommerce-billecta-payment-gateway' ),
	  '7'  => __( '7', 'woocommerce-billecta-payment-gateway' ),
	  '8'  => __( '8', 'woocommerce-billecta-payment-gateway' ),
	  '9'  => __( '9', 'woocommerce-billecta-payment-gateway' ),
	  '10'  => __( '10', 'woocommerce-billecta-payment-gateway' ),
	  '11'  => __( '11', 'woocommerce-billecta-payment-gateway' ),
	  '12'  => __( '12', 'woocommerce-billecta-payment-gateway' ),

    ),
					'label' 		=> __( 'Partial payment Enable Custom Payment', 'woocommerce-billecta-payment-gateway' ),
					'default' 		=> 'no'
					),
	'text_on_button' => array(
					'title' 		=> __( 'Text on Button', 'woocommerce-billecta-payment-gateway' ),
					'type' 			=> 'text',
					'label' 		=> __( 'Text on Button Custom Payment', 'woocommerce-billecta-payment-gateway' ),
					'default' 		=> 'Submit'
					),
					
'color_on_button' => array(
					'title' 		=> __( 'color on button', 'woocommerce-billecta-payment-gateway' ),
					'type' 			=> 'text',
					'label' 		=> __( 'Color on button Custom Payment', 'woocommerce-billecta-payment-gateway' ),
					'default' 		=> 'red'
					),
					
	'username' => array(
					'title' 		=> __( 'Username', 'woocommerce-billecta-payment-gateway' ),
					'description' 	=> __( 'Please enter the Username that you used to logged in into the billecta', 'woocommerce-billecta-payment-gateway' ),
					'type' 			=> 'text',
					'label' 		=> __( 'Username Custom Payment', 'woocommerce-billecta-payment-gateway' ),
					'desc_tip'		=> true,
					),
		'password' => array(
					'title' 		=> __( 'Password', 'woocommerce-billecta-payment-gateway' ),
					'type' 			=> 'password',
					'description' 	=> __( 'Please enter the password that you used to logged in into the billecta', 'woocommerce-billecta-payment-gateway' ),
					'label' 		=> __( 'Password Custom Payment', 'woocommerce-billecta-payment-gateway' ),
					'desc_tip'		=> true,
					),
			 );
	}
	/**
	 * Admin Panel Options
	 * - Options for bits like 'title' and availability on a country-by-country basis
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_options() {
		?>
		<h3><?php _e( 'Billecta Payment Settings', 'woocommerce-billecta-payment-gateway' ); ?></h3>
			<div id="poststuff">
				<div id="post-body" class="metabox-holder columns-2">
					<div id="post-body-content">
						<table class="form-table">
							<?php $this->generate_settings_html();?>
						</table><!--/.form-table-->
					</div>
					<div id="postbox-container-1" class="postbox-container">
	                        <div id="side-sortables" class="meta-box-sortables ui-sortable"> 
	                           
     							<div class="postbox ">
	                                <div class="handlediv" title="Click to toggle"><br></div>
	                                <h3 class="hndle"><span><i class="dashicons dashicons-update"></i>&nbsp;&nbsp;Upgrade to Pro</span></h3>
	                                <div class="inside">
	                                    <div class="support-widget">
	                                        <ul>
	                                            <li>» Full Form Builder</li>
	                                            <li>» Custom Gateway Icon</li>
	                                            <li>» Order Status After Checkout</li>
	                                            <li>» Custom API Requests</li>
	                                            <li>» Debugging Mode</li>
	                                            <li>» Auto Hassle-Free Updates</li>
	                                            <li>» High Priority Customer Support</li>
	                                        </ul>
											<a href="https://wpruby.com/plugin/woocommerce-custom-payment-gateway-pro/" class="button wpruby_button" target="_blank"><span class="dashicons dashicons-star-filled"></span> Upgrade Now</a> 
	                                    </div>
	                                </div>
	                            </div>
	                            <div class="postbox ">
	                                <div class="handlediv" title="Click to toggle"><br></div>
	                                <h3 class="hndle"><span><i class="dashicons dashicons-editor-help"></i>&nbsp;&nbsp;Plugin Support</span></h3>
	                                <div class="inside">
	                                    <div class="support-widget">
	                                        <p>
	                                        <img style="width: 70%;margin: 0 auto;position: relative;display: inherit;" src="https://wpruby.com/wp-content/uploads/2016/03/wpruby_logo_with_ruby_color-300x88.png">
	                                        <br/>
	                                        Got a Question, Idea, Problem or Praise?</p>
	                                        <ul>
												<li>» Please leave us a <a target="_blank" href="https://wordpress.org/support/view/plugin-reviews/woocommerce-billecta-payment-gateway?filter=5#postform">★★★★★</a> rating.</li>
	                                            <li>» <a href="https://wpruby.com/submit-ticket/" target="_blank">Support Request</a></li>
	                                            <li>» <a href="https://wpruby.com/knowledgebase_category/woocommerce-custom-payment-gateway-pro/" target="_blank">Documentation and Common issues.</a></li>
	                                            <li>» <a href="https://wpruby.com/plugins/" target="_blank">Our Plugins Shop</a></li>
	                                        </ul>

	                                    </div>
	                                </div>
	                            </div>
	                       
	                            <div class="postbox rss-postbox">
	    							<div class="handlediv" title="Click to toggle"><br></div>
	    								<h3 class="hndle"><span><i class="fa fa-wordpress"></i>&nbsp;&nbsp;WPRuby Blog</span></h3>
	    								<div class="inside">
											<div class="rss-widget">
												<?php
	    											wp_widget_rss_output(array(
	    													'url' => 'https://wpruby.com/feed/',
	    													'title' => 'WPRuby Blog',
	    													'items' => 3,
	    													'show_summary' => 0,
	    													'show_author' => 0,
	    													'show_date' => 1,
	    											));
	    										?>
	    									</div>
	    								</div>
	    						</div>

	                        </div>
	                    </div>
                    </div>
				</div>
				<div class="clear"></div>
				<style type="text/css">
				.wpruby_button{
					background-color:#4CAF50 !important;
					border-color:#4CAF50 !important;
					color:#ffffff !important;
					width:100%;
					padding:5px !important;
					text-align:center;
					height:35px !important;
					font-size:12pt !important;
				}
				</style>
				<?php
	}
	public function process_payment( $order_id ) {
		global $woocommerce;
		$order = new WC_Order( $order_id );
		// Mark as on-hold (we're awaiting the cheque)
		$order->update_status('on-hold', __( 'Awaiting payment', 'woocommerce-billecta-payment-gateway' ));
		// Reduce stock levels
		$order->reduce_order_stock();
		if(isset($_POST[ $this->id.'-admin-note']) && trim($_POST[ $this->id.'-admin-note'])!=''){
			$order->add_order_note(esc_html($_POST[ $this->id.'-admin-note']),1);
		}
		// Remove cart
		$woocommerce->cart->empty_cart();
		// Return thankyou redirect
		return array(
			'result' => 'success',
			'redirect' => $this->get_return_url( $order )
		);	
	}

	public function payment_fields(){
		?>
       
		<fieldset>
			<p class="form-row form-row-wide">
				<label for="<?php echo $this->id; ?>-admin-note"><?php echo esc_attr($this->description); ?> <span class="required">*</span></label>
				 <textarea id="<?php echo $this->id; ?>-admin-note" class="input-text" type="text" name="<?php echo $this->id; ?>-admin-note"></textarea>
			</p>	
             I want to pay:		
             <?php
			// print_r($this);
			 $this->init_settings();
			  $this->full_payment = $this->get_option( 'Full_payment' );
			   $this->inoice_fee = $this->get_option( 'inoice_fee' );
			    $this->num_invoices = $this->get_option( 'num_invoices' );
			   
	  $this->partial_payment = $this->get_option( 'partial_payment' );
			 if($this->full_payment=="yes")
			 {?>
				Full payment <input type="radio"  id="<?php echo $this->id; ?>payment-option" name="<?php echo $this->id; ?>payment-option" val="full" />
				<?php }
				 if($this->partial_payment=="yes")
			 {?><br />
				Partial Payment <input type="radio"  id="<?php echo $this->id; ?>payment-option" name="<?php echo $this->id; ?>payment-option"  value="par"/>
				<?php }
			 
			 //echo $this->settings->Full_payment."<div>hhhhhhhhhhhh".$this->Full_payment."</div>";
			 
			 ?>	
             <p id="full_content">Invoicing fee <?php echo $this->inoice_fee;?> </p>
               <p id="par_content">Amount of parts <?php echo $this->num_invoices;?> 
               <div>Invoicing fee: <?php ?></div>
               </p>
               		
			<div class="clear"></div>
		</fieldset>
		<?php
	}
}